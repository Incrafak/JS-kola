function determineAgeCategory() 
{
    let name = document.getElementById("name").value;
    let rc = document.getElementById("rc").value;
    let yearOfBirth;
    let ageCategory;
    
    if (rc.length >= 6) 
    {
        let rcParts = rc.split("/");
        yearOfBirth = parseInt(rcParts[0].slice(0, 2));
        if (yearOfBirth <= 24) {
            yearOfBirth += 2000;
        } else {
            yearOfBirth += 1900;
        }
    } else 
    {
        document.getElementById("result").innerHTML = "Špatně zadané rodné číslo.";
        return;
    }
    let currentYear = new Date().getFullYear();
    let age = currentYear - yearOfBirth;
    
    switch (true) 
    {
        case (age <= 2):
            ageCategory = "Novorozenec";
            break;
        case (age <= 6):
            ageCategory = "Předškolní věk";
            break;
        case (age <= 15):
            ageCategory = "Školák";
            break;
        case (age <= 19):
            ageCategory = "Středoškolák";
            break;
            case (age <= 25):
                ageCategory = "Studující";
                break;
            case (age <= 65):
                ageCategory = "Pracující";
                break;
            default:
                ageCategory = "Důchodce";
        }
        document.getElementById("result").innerHTML = "Jméno: " + name + "<br>Věk: " + age + "<br>Věková kategorie: " + ageCategory;
    }
    